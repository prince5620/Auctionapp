class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/image';  
  static String SplashScreen = '$imagePath/splash.png';
}