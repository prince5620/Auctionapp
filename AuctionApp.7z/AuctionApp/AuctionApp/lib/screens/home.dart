import 'package:flutter/material.dart';
import 'package:project/screens/about.dart';
import 'package:project/screens/itemdetail.dart';
import 'package:project/screens/licenseplate.dart';
import 'package:project/screens/mobilenumber.dart';
import 'package:project/screens/profilesscreen.dart';
import 'package:project/widget/bottomnavbar.dart';
import 'package:project/widget/cardWidget.dart';
import 'package:project/widget/custom_drawer.dart';

class HomePage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff181816),
      key: _scaffoldKey,
      
      bottomNavigationBar: CustomBottomNavigationBar(),
       endDrawer: Drawer(
          backgroundColor:   Color(0xff181816),
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
             SizedBox(height: 50,),
               ListTile(
                leading: Icon(Icons.home,color: Colors.grey,),
                title: Text('Home Page',style: TextStyle(color: Colors.white,fontSize: 16),),
                onTap: () {
                   Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        HomePage())));
                },
              ),
              ListTile(
                leading: Image.asset('assets/icon/licenceplate.png'),
                title: Text('Licence Plate',style: TextStyle(color: Colors.white,fontSize: 16),),
                onTap: () {
                   Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        LicencePlate())));
                },
              ),
              ListTile(
                leading: Image.asset('assets/icon/mobile.png'),
                title: Text('Mobile Number',style: TextStyle(color: Colors.white,fontSize: 16),),
                onTap: () {
                 Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        MobileNumber())));
                },
              ),
            
              ListTile(
                leading: Image.asset('assets/icon/about.png'),
                title: Text('About',style: TextStyle(color: Colors.white,fontSize: 16),),
                onTap: () {
                   Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        AboutScreen())));
                },
              ),
              ListTile(
                leading: Image.asset('assets/icon/profile.png'),
                title: Text('Profile',style: TextStyle(color: Colors.white,fontSize: 16),),
                onTap: () {
                   Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        ProfileScreen())));
                },
              ),
            ],
          ),
        ),
      body: ListView(
        children: [
          Stack(
            children: [
              Container(height:365,
                color: Color(0xff4D4D4D),
                width: double.infinity,
               
                
                  child: 
                  Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.only(left:20,
                        bottom: 5,),
                        child: Text(
                          'Your Spot to buy or sell',
                          style: TextStyle(fontFamily: 'Roboto Slab',
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left:20,
                        bottom: 10,),
                        child: Text(
                          'Your Premium',
                          style: TextStyle(fontFamily: 'Roboto Slab',
                            color: Colors.white,
                            fontSize: 32,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left:20,
                        bottom: 10,),
                        child: Text(
                          'Number',
                          style: TextStyle(fontFamily: 'Roboto Slab',
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: AppBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  title: Row(
                    children: [
                      Flexible(
                        child: Image.asset(
                          'assets/image/logo.png',
                          fit: BoxFit.contain,
                          height: 32,
                        ),
                      ),
                    ],
                  ),
                  automaticallyImplyLeading: false,
                  actions: [
                    IconButton(
                      icon: Icon(Icons.menu,color: Colors.white,),
                      onPressed: () {
                        _scaffoldKey.currentState?.openEndDrawer();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 20,),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(margin: EdgeInsets.only(left: 20),
                    child: Text('Featured plate numbers', style: TextStyle(fontFamily: 'Roboto Slab',
                                color: Colors.white,
                                fontSize: 20,
                                 fontWeight: FontWeight.w600,
                              ),),
                  ),
                  InkWell(
                    onTap:(){
                       Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        LicencePlate())));
                    },
                    child:
                  Row(
                    children: [
                      Container(margin: EdgeInsets.only(right: 2),
                        child: Text('More', style: TextStyle(fontFamily: 'Roboto Slab',
                                    color: Colors.white,
                                    fontSize: 12,
                                     fontWeight: FontWeight.w400,
                                  ),),
                      ),
                       Container(margin: EdgeInsets.only(right: 20),
                        child: Icon(Icons.arrow_forward,color: Colors.white,size: 16,)
                      ),
                    ],
                  ),)
              ],
            ),
           
               
                Container(margin: EdgeInsets.only(left: 20,top: 4),
                child: Text('Premium plate number ', style: TextStyle(fontFamily: 'Roboto Slab',
                            color: Colors.white,
                            fontWeight: FontWeight.w100,
                            fontSize: 14,
                          ),),
              ),
               Container(
                margin: EdgeInsets.all(10),
      height: 155, // Set the height of the horizontal ListView
      child:
       ListView(
        
        scrollDirection: Axis.horizontal,
        // itemCount: 4, // Number of cards
       children: [
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),

       ],
      ),
    ),SizedBox(height: 20,),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(margin: EdgeInsets.only(left: 20),
                    child: Text('Featured Mobile number', style: TextStyle(fontFamily: 'Roboto Slab',
                                color: Colors.white,
                                fontSize: 20,
                                 fontWeight: FontWeight.w600,
                              ),),
                  ),
                  InkWell(
                    onTap:(){
                          Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: ((context) =>
                                                        MobileNumber())));
                    },
                    child:
                  Row(
                    children: [
                      Container(margin: EdgeInsets.only(right: 2),
                        child: Text('More', style: TextStyle(fontFamily: 'Roboto Slab',
                                    color: Colors.white,
                                    fontSize: 12,
                                     fontWeight: FontWeight.w400,
                                  ),),
                      ),
                       Container(margin: EdgeInsets.only(right: 20),
                        child: Icon(Icons.arrow_forward,color: Colors.white,size: 16,)
                      ),
                    ],
                  ),)

              ],
            ),
           
               
                Container(margin: EdgeInsets.only(left: 20,top: 4),
                child: Text('Premium plate number ', style: TextStyle(fontFamily: 'Roboto Slab',
                            color: Colors.white,
                            fontWeight: FontWeight.w100,
                            fontSize: 14,
                          ),),
              ),
               Container(
                margin: EdgeInsets.all(10),
      height: 155, // Set the height of the horizontal ListView
      child: ListView(
        
        scrollDirection: Axis.horizontal,
        // itemCount: 4, // Number of cards
       children: [
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),
        CustomCardWidget(),

       ],
      ),
    ),
    SizedBox(height: 50,)
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: HomePage(),
  ));
}
